function result=iCAP(Y0,X0,G)
% ========================================================================
% result=iCAP(Y0,X0,G)
% ========================================================================
% INPUTS:
% Y0 : a n x 1 vector containing the response variable
% X0 : a n x p matrix containig the observed values for the predictors
% G  : a {K}-dimensional cell array the group structure:
%      each element contains the indices in a group
% ========================================================================
% OUTPUT:
% result : a structure containing:
%          .T    : the value for the penalty at the breakpoints
%          .beta : the value of the fitted coefficients at the breakpoints
% ========================================================================
% Refer to README.txt included in this package for copyright information
% ========================================================================

n_g=length(G); % # of Groups
p=size(X0,2); % # of Variables
n=size(X0,1); % # of Obs
XY0=X0'*Y0;
XX0=X0'*X0;
X=X0;
S=sparse(p,n_g);
d=zeros(p,1);
maxIter=1e3;
Delta=sparse(n_g,1);
beta(1,:)=zeros(1,p);
numErr=(p^4+n*p^3)*eps;

rList=[]; % regularized List
for i=1:n_g
rList=union(rList,G{i});
end
uList=setdiff(1:p,rList); %unregularized List

%orthogonalization
Y=Y0-X0(:,uList)*(X0(:,uList)\Y0);
X(:,rList)=X0(:,rList)-X0(:,uList)*(X0(:,uList)\X0(:,rList));
%%%Need2Orthogonalize=0;

%Create Sign
for i=1:n_g
S(G{i},i)=sign(X(:,G{i})'*Y); %sign vectors
end;

%Leave Zero
ETA=X*S;
[dummy,i]=max(ETA'*Y);
Delta(i)=1;
M=[i];
Mc=setdiff(1:n_g,M);
for i=1:length(M)
d(G{M(i)})=S(G{M(i)},M(i))*Delta(M(i));
end;
d(uList)= -X0(:,uList)\(X0(:,rList)*d(rList));

for t=2:maxIter
    
    %scenario 1: correlation crossing zero
    bs=X(:,rList)'*Y./(X(:,rList)'*ETA(:,M)*Delta(M));
    fw=find(bs>numErr);  % going forward
    [b(1),j(1)]=min(bs(fw));
    j(1)=rList(fw(j(1))); %variable index
   
    %scenario 2: leaving zero
    bs=(ETA(:,Mc)'*Y-ETA(:,M(1))'*Y)...
        ./(ETA(:,Mc)'*ETA*Delta-ETA(:,M(1))'*ETA*Delta);
    fw=find(bs>numErr);  % going forward p*eps replaces zero for numerical err
    if isempty(fw)
        b(2)=Inf;
    else
        [b(2),j(2)]=min(bs(fw)); %first one that leaves
        j(2)=Mc(fw(j(2))); %group index
    end;
    
    %scenario 3: hitting maximum boundary
    
    b3=[];j3=[];
    for i=1:length(M) %for each group
        mii=intersect(G{M(i)},rList); %locate regularized variables
        uii=intersect(G{M(i)},uList); %locate free variables
        if isempty(uii)
            continue;
        end;
        bs=(sign(d(uii)).*beta(t-1,uii)'-abs(beta(t-1,mii(1))))...
            ./(sign(beta(t-1,mii(1)))*(d(mii(1)))-abs(d(uii))); %find crossing
        fw=find(bs>numErr); %going forward
        if isempty(fw)
            continue;
        end;
        [bs,js]=min(bs(fw)); %find first crossing within group
        b3=[b3 bs]; %add to list of variables that first crossed within G
        j3=[j3 uii(fw(js))];
    end;
    if isempty(b3)
        b(3)=Inf;
    else
        [b(3) j(3)]=min(b3); %find overall first crossing
        j(3)=j3(j(3));
    end;
    
    %scenario 4: whole group hitting zero
    bs=0;
    for i=1:length(M)
        ii=intersect(G{M(i)},rList);
        bs(i)=-beta(t-1,ii(1))./d(ii(1));           
    end
    fw=find(bs>numErr);
    if isempty(fw)
        b(4)=Inf;
    else
        [b(4),j(4)]=min(bs(fw));
        j(4)=M(fw(j(4)));
    end; 
    
    %judge which scenario happens first
    [b_f,action]=min(b);
    j_f=j(action); %j(1), j(3) are variable index, j(2), j(4) are group index!!!!
    
    switch(action)     
        
        case(1) %crossing zero
            
            GroupOfj_f=find(S(j_f,:));
            if length(GroupOfj_f)>1
                error('groupStructure:Ovelap','Overlapping Group!!!!');
            end;
            
            switch(ismember(GroupOfj_f,M))                
                
                case(1) %within included group --> released free
                    
                    %update beta
                    beta(t,:)=beta(t-1,:)+b_f*d';
    
                    uList=[uList j_f]; %update uList
                    rList=setdiff(rList,j_f); %update rList
                    
                    Y=Y0-X0*beta(t,:)';
                    %orthogonalize                    
                    X(:,rList)=X0(:,rList)-...
                        X0(:,uList)*(X0(:,uList)\X0(:,rList));
                    
                    %update signs
                    S(j_f,GroupOfj_f)=0;
                    
                    if sum(sum(abs(S),1)==0) %complete free group
                        term='OLS';
                        break;
                    end;
                        
                    ETA=X*S;                        
                    Delta(M)=inv(ETA(:,M)'*ETA(:,M))*ones(length(M),1);
                    
                    %update direction
                    for i=1:length(M)
                        d(G{M(i)})=S(G{M(i)},M(i))*Delta(M(i));
                    end;
                    d(uList)= -X0(:,uList)\(X0(:,rList)*d(rList));
                        
                case(0) %within not yet included group -> change sign
                    
                    %update beta
                    beta(t,:)=beta(t-1,:)+b_f*d';
                    
                    Y=Y0-X0*beta(t,:)';
                    
                    %update sign
                    S(j_f,GroupOfj_f)=sign(-X(:,j_f)'*ETA(:,M)*Delta(M));
                    ETA=X*S;
                    
            end;
        
        case(2) %leaving zero -->calculate the new equiangular direction
            
            %update beta
            beta(t,:)=beta(t-1,:)+b_f*d';
            
            M=union(M,j_f); %update M
            Mc=setdiff(Mc,j_f); %update M's complement
        
            Y=Y0-X0*beta(t,:)';
            
            ETA=X*S;                        
            Delta(M)=inv(ETA(:,M)'*ETA(:,M))*ones(length(M),1);
            for i=1:length(M)
                d(G{M(i)})=S(G{M(i)},M(i))*Delta(M(i)); %update direction
            end;
            d(uList)= -X0(:,uList)\(X0(:,rList)*d(rList)); %update direction
            
        case(3) %hitting maximum boundary -> regularized it!
            %update beta
            
            beta(t,:)=beta(t-1,:)+b_f*d';
            
            uList=setdiff(uList,j_f); %update uList
            rList=union(rList,j_f); %update rList
                    
            Y=Y0-X0*beta(t,:)';
            %orthogonalize
            X(:,rList)=X0(:,rList)-X0(:,uList)*(X0(:,uList)\X0(:,rList));
                    
            %update signs
            GroupOfj_f=[];
            for i=1:n_g
                if ismember(j_f,G{i})
                    GroupOfj_f=i;
                end;
                continue;
            end;
            
            S(j_f,GroupOfj_f)=sign(beta(t,j_f));
                             
            ETA=X*S;                        
            Delta(M)=inv(ETA(:,M)'*ETA(:,M))*ones(length(M),1);
                    
            %update direction
            for i=1:length(M)
                d(G{M(i)})=S(G{M(i)},M(i))*Delta(M(i));
            end;
            d(uList)= -X0(:,uList)\(X0(:,rList)*d(rList));
            
        case(4) %group max crossing zero -> stay at zero
            %update beta
            
            beta(t,:)=beta(t-1,:)+b_f*d';
            
            rList=union(rList,G{j_f}); %update rList
            uList=setdiff(uList,G{j_f}); %update uList
                    
            Y=Y0-X0*beta(t,:)';
            %orthogonalize
            X(:,rList)=X0(:,rList)-X0(:,uList)*(X0(:,uList)\X0(:,rList));
                    
            %update signs
            
            M=setdiff(M,j_f);
            Mc=union(Mc,j_f);            
                                    
            Delta(M)=inv(ETA(:,M)'*ETA(:,M))*ones(length(M),1);
            Delta(Mc)=0;
                    
            %update direction
            for i=1:length(M)
                d(G{M(i)})=S(G{M(i)},M(i))*Delta(M(i));
            end;
            for i=1:length(Mc)
                d(G{Mc(i)})=0;
            end;
            d(uList)= -X0(:,uList)\(X0(:,rList)*d(rList));
            
            S(G{j_f},j_f)=sign(-X(:,G{j_f})'*X*d);
            ETA=X*S;

    end;

    %temination if perfect fit
    if (std(Y)<n*p^2*eps)
        term='Full Fit';
        break;
    end;
end;

result.term=term;
result.T=zeros(1,size(beta,1));
result.beta=beta;
for i=1:length(result.T)
    for j=1:n_g
        result.T(i)=result.T(i)+max(abs(beta(i,G{j})));
    end;
end;
