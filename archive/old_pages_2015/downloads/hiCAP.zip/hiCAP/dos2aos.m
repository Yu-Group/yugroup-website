function allOffsprings=dos2aos(node,directOffsprings)

if isempty(directOffsprings{node})
    allOffsprings=[];
    return;
else
    allOffsprings=directOffsprings{node};
    for i=directOffsprings{node}
        allOffsprings=union(allOffsprings,dos2aos(i,directOffsprings));
    end;
end

