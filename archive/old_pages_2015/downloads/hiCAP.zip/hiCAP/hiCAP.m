function result=hiCAP(Y0,X0,links)
% ========================================================================
% result=hiCAP(Y0,X0,links)
% ========================================================================
% INPUTS:
% Y0 : a n x 1 vector containing the response variable
% X0 : a n x p matrix containig the observed values for the predictors
% G  : a {K}-dimensional cell array describing the hierarchical tree:
%      each element contains a node in its first position and its children
%      G{1} must contain the root
% ========================================================================
% OUTPUT:
% result : a structure containing:
%          .T    : the value for the penalty at the breakpoints
%          .beta : the value of the fitted coefficients at the breakpoints
% ========================================================================
% Refer to README.txt included in this package for copyright information
% ========================================================================

global numErr;global XY;global T;global zGroup;global zList;global mGroup;
global mList;global head; global subTrees;global ETA;global d; global S;
global Delta;global cors;global pens;global action;global Y;global X;
global superTree;global p;global bs;

n=size(X0,1);
theRoot=links{1}(1);
maxIter=1e4;
p=size(X0,2);
numErr=(p^3+n*p^2)*eps;
XY=X0'*Y0;
X=X0;
Y=Y0;
T=link2tree(p,links); %specified tree stucture
superTree=T;
zGroup=[]; %zero groups
zList=[]; %zero variables
mGroup=theRoot; %maximum groups
mList=[]; %maximum variables
subTrees=dos2tree(cell(1,p));
ETA=zeros(n,p);
d=zeros(p,1);
S=sign(XY);
Delta=zeros(p,1);
cors=abs(XY);
pens=ones(p,1);
head=(cors~=0); %whether a tree is headed, i.e. X(i) is at the max of subTree(i)
action=zeros(1,p);
beta=zeros(1,p);
ignoreLists=zeros(p,7);


%take initial step
initialStep(theRoot);

for t=2:maxIter
    
    %scenario 1: zList's variables' correlation crossing zero
    sc=1;
    tI=intersect(zList,find((abs(X'*X*d )>numErr)&(~ignoreLists(:,sc))));
    if isempty(tI)
        b(sc)=inf;
        j(sc)=-1;
    else
     bs=(X(:,tI)'*Y)./(X(:,tI)'*X*d);
     fw=find(bs>0);  % going forward
     if isempty(fw)
         b(sc)=inf;
         j(sc)=-1;
     else
         [b(sc),j(sc)]=min(bs(fw));
         j(sc)=tI(nOrth(fw(j(sc)))); %variable index
     end;
    end;
    
    %scenario 2; mList's variables' correlation reach zero
    sc=2;tmpList=intersect(mList,find( head & ~ignoreLists(:,sc) ));
    bs=(X(:,tmpList)'*Y)./(X(:,tmpList)'*X*d);
    fw=find(bs>0);  % going forward
     if isempty(fw)
         b(sc)=inf;
         j(sc)=-1;
     else
         [b(sc),j(sc)]=min(bs(fw));
         j(sc)=tmpList(fw(j(sc))); %variable index
     end;
    
    %scenario 3: combine Zero tree;
    sc=3;
    combineZeroSubTrees(theRoot);
    tI=intersect(superTree.allOffsprings{theRoot},find(~ignoreLists(:,sc))); %potential combine points
    fw=find(bs(tI)>0);  % going forward
    if isempty(fw)
        b(sc)=inf;
        j(sc)=-1;
    else
        [b(sc),j(sc)]=min(bs(tI(fw)));
        j(sc)=tI(fw(j(sc))); %group index
    end;
    
    %scenario 4: split trees
    sc=4;
    tI=intersect(setdiff(1:p,subTrees.roots),find(~ignoreLists(:,sc))); %potential split points
    for i=1:length(tI)
        parent=subTrees.parentRoot(tI(i));
        if abs((ETA(:,tI(i))'*X*d)./pens(tI(i))-ETA(:,parent)'*X*d/pens(parent) )<numErr
            bs(tI(i))=inf;
        else
            bs(tI(i))=(ETA(:,tI(i))'*Y./pens(tI(i))-ETA(:,parent)'*Y/pens(parent))...
                ./((ETA(:,tI(i))'*X*d)./pens(tI(i))-ETA(:,parent)'*X*d/pens(parent) );
        end;
    end;    
    fw=find(bs(tI)>0);  % going forward
    if isempty(fw)
        b(sc)=inf;
        j(sc)=-1;
    else
        [b(sc),j(sc)]=min(bs(tI(fw)));
        j(sc)=tI(fw(j(sc))); %group index
    end;
    
          
    %scenario 5: subTree hitting max of parent-subTree
    sc=5;
    tI=intersect(setdiff(mGroup,theRoot),find(~ignoreLists(:,sc))); %potential merging points
    for i=1:length(tI)
        parent=superTree.parents(tI(i));
        i1=find(head( subTrees.groups{tI(i)} ),1);
        i1=subTrees.groups{tI(i)}(i1);
        m1=find(head( subTrees.groups{parent} ),1);
        m1=subTrees.groups{parent}(m1);
        if abs(sign(beta(t-1,m1))*(d(m1))-abs(d(i1)))<numErr
            bs(tI(i))=inf;
        else
            bs(tI(i))=(sign(d(i1)).*beta(t-1,i1)'-abs(beta(t-1,m1)))...
                 ./(sign(beta(t-1,m1))*(d(m1))-abs(d(i1))); %find crossing
        end;
    end;    
    fw=find(bs(tI)>0);  % going forward
    if isempty(fw)
        b(sc)=inf;
        j(sc)=-1;
    else
        [b(sc),j(sc)]=min(bs(tI(fw)));
        j(sc)=tI(fw(j(sc))); %group index
    end;
    
    %scenario 6: unregularized head variable hit group max
    sc=6;
    tI=intersect(find(~head),find(~ignoreLists(:,sc)));
    for i=1:length(tI)
        m1=find(head( subTrees.groups{subTrees.parentRoot(tI(i))} ),1);;
        m1=subTrees.groups{subTrees.parentRoot(tI(i))}(m1);
        i1=tI(i);
        bs(tI(i))=(sign(d(i1)).*beta(t-1,i1)'-abs(beta(t-1,m1)))...
                 ./(sign(beta(t-1,m1))*(d(m1))-abs(d(i1))); %find crossing
    end;
    
    fw=find(bs(tI)>0);  % going forward
    if isempty(fw)
        b(sc)=inf;
        j(sc)=-1;
    else
        [b(sc),j(sc)]=min(bs(tI(fw)));
        j(sc)=tI(fw(j(sc))); %group index
    end;


    %scenario 7: group beta hitting zero
    sc=7;
    tI=intersect(mGroup,find(~ignoreLists(:,sc)));
    for i=1:length(tI)
        i1=find(head( subTrees.groups{tI(i)} ),1);
        i1=subTrees.groups{tI(i)}(i1);
        bs(tI(i))=-beta(t-1,i1)/d(i1);
    end;
    fw=find(bs(tI)>0);  % going forward
    if isempty(fw)
        b(sc)=inf;
        j(sc)=-1;
    else
        [b(sc),j(sc)]=min(bs(tI(fw)));
        j(sc)=tI(fw(j(sc))); %group index
    end;
    
    %judge which scenario happens first
    [b_f,action]=min(b);
    j_f=j(action); %variable indices

    beta(t,:)=beta(t-1,:)+b_f*d';
    Y=Y0-X0*beta(t,:)';

if (b_f==inf) | (sum(abs(X'*Y))<(p*numErr))
    %beta(t,:)=X\Y0;
    term='OLS0';
    break;
end;


    ignoreLists=zeros(p,7);
    ignoreLists(j_f,action)=1;

    switch(action)     
        
        case(1) %flip sign
            %update beta and sign
            S(j_f)=sign(-X(:,j_f)'*X*d);
            tI=subTrees.parentRoot(j_f); %group #
            ETA(:,tI)=X(:,subTrees.groups{tI})*S(subTrees.groups{tI});

            
        case(2) %drop the head of subTree
            %update beta and sign
            if ismember(j_f,T.leafs) %leaf reached zero correlation, complete
                  term='OLS2';
                  break;
            end;
            
            S(j_f)=0;
            head(j_f)=0;
            %calculate group variable and penalties
            tI=subTrees.ancestors{j_f}; %all ancestors of the break point
            ETA(:,j_f)=X(:,subTrees.groups{j_f})*S(subTrees.groups{j_f});
            for i=1:length(tI)
                ETA(:,tI(i))=X(:,subTrees.groups{tI(i)})*S(subTrees.groups{tI(i)});
            end;    
            updateDirection();
            
        case(3) 

            if ismember(superTree.parents(j_f),mList)  %zero join model
            
                %move subTree from zList to mList
                mGroup=union(mGroup,j_f);
                mList=union(mList,subTrees.groups{j_f});
                zGroup=setdiff(zGroup,j_f);
                zList=setdiff(zList,subTrees.groups{j_f});            
                
            elseif ismember(superTree.parents(j_f),zList)  %combine zero subs
                    
                zGroup=setdiff(zGroup,j_f);
                tI=superTree.parents(j_f); %the new larger subTree
                subTrees.directOffsprings{T.parents(j_f)}=...
                    union(subTrees.directOffsprings{T.parents(j_f)},j_f);
                superTree.directOffsprings{tI}=...
                    setdiff(superTree.directOffsprings{tI},j_f);
                superTree.directOffsprings{tI}=...
                    union(superTree.directOffsprings{tI},...
                    superTree.directOffsprings{j_f});
                superTree.directOffsprings{j_f}=[];
                
                subTrees=dos2tree(subTrees.directOffsprings);
                superTree=dos2Tree(superTree.directOffsprings);             
                
                tI=subTrees.ancestors{j_f}; %all ancestors of the break point
                pens(tI)=pens(tI)+pens(j_f);
                    for i=1:length(tI)
                        ETA(:,tI(i))=X(:,subTrees.groups{tI(i)})*S(subTrees.groups{tI(i)});
                    end;    
            
            else
                error('case3.3','zList+mList~=1:p');
            end
                
            updateDirection();
                
        case(4)
            
                %split the subTree into 2
                tI=subTrees.parentRoot(j_f); %the older larger subTree
                superTree.directOffsprings{tI}=...
                    union(superTree.directOffsprings{tI},j_f);
                superTree.directOffsprings{j_f}=intersect(superTree.directOffsprings{tI},...
                                                T.allOffsprings{j_f});
                superTree.directOffsprings{tI}=...
                    setdiff(superTree.directOffsprings{tI},...
                    superTree.directOffsprings{j_f});
                tI=subTrees.ancestors{j_f}; %all ancestors of the break point
                subTrees.directOffsprings{T.parents(j_f)}=...
                    setdiff(subTrees.directOffsprings{T.parents(j_f)},j_f);                
                subTrees=dos2tree(subTrees.directOffsprings);
                superTree=dos2tree(superTree.directOffsprings);
                
                ETA(:,j_f)=X(:,subTrees.groups{j_f})*S(subTrees.groups{j_f});
                pens(tI)=pens(tI)-pens(j_f);
                for i=1:length(tI)
                        ETA(:,tI(i))=X(:,subTrees.groups{tI(i)})*S(subTrees.groups{tI(i)});
                end;
            
            if ismember(j_f,mList); %update mGroup and direction
                mGroup=union(mGroup,j_f);
                updateDirection();
            elseif ismember(j_f,zList); %split zeroTree, direction doesn't change
                zGroup=union(zGroup,j_f);
            else 
                error('case4.3','zList+mList~=1:p');
            end;
            
        case(5) %combine the max-subTrees
            
            mGroup=setdiff(mGroup,j_f);
            tI=superTree.parents(j_f); %the new larger subTree
            subTrees.directOffsprings{T.parents(j_f)}=...
                union(subTrees.directOffsprings{T.parents(j_f)},j_f);
            superTree.directOffsprings{tI}=...
                setdiff(superTree.directOffsprings{tI},j_f);
            superTree.directOffsprings{tI}=...
                union(superTree.directOffsprings{tI},...
                superTree.directOffsprings{j_f});
            superTree.directOffsprings{j_f}=[];

            subTrees=dos2tree(subTrees.directOffsprings);
            superTree=dos2tree(superTree.directOffsprings);             

            tI=subTrees.ancestors{j_f}; %all ancestors of the break point
            ETA(:,j_f)=X(:,subTrees.groups{j_f})*S(subTrees.groups{j_f});
            pens(tI)=pens(tI)+pens(j_f);
                for i=1:length(tI)
                    ETA(:,tI(i))=X(:,subTrees.groups{tI(i)})*S(subTrees.groups{tI(i)});
                end;    
                
            updateDirection();
            
        case(6) %make the variable head again
            
            S(j_f)=sign(beta(t,j_f));
            head(j_f)=1;
            %calculate group variable and penalties
            tI=subTrees.ancestors{j_f}; %all ancestors of the head
            ETA(:,j_f)=X(:,subTrees.groups{j_f})*S(subTrees.groups{j_f});
            for i=1:length(tI)
                ETA(:,tI(i))=X(:,subTrees.groups{tI(i)})*S(subTrees.groups{tI(i)});
            end;    
            updateDirection();
            
        case(7)
            
            %move subTree from zList to mList
            mGroup=setdiff(mGroup,j_f);
            mList=setdiff(mList,subTrees.groups{j_f});
            zGroup=union(zGroup,j_f);
            zList=union(zList,subTrees.groups{j_f});
            updateDirection();
    
    end;

end;

result.beta=beta;
result.term=term;
result.T=zeros(1,size(beta,1));

for t=1:size(beta,1)
    for i=1:p
        result.T(t)=result.T(t)+max( abs( beta(t,T.groups{i}) ) );
    end;
end;
    
%====================subFunctions====================

%--------------Initial Step---------------------------
function initialStep(i)

global numErr;global XY;global T;global zGroup;global zList;global mGroup;
global mList;global head; global subTrees;global ETA;global d; global S;
global Delta;global cors;global pens;global b;global action;global Y;global X;
global superTree;global p;

optimTree(i);

mGroup=i;
mList=subTrees.groups{mGroup};
zList=setdiff(1:p,mList);
zGroup=setdiff(subTrees.roots,mGroup);
d(subTrees.groups{mGroup})=S(subTrees.groups{mGroup});

for j=1:p
ETA(:,j)=X(:,subTrees.groups{j})*S(subTrees.groups{j});
end;

return;

%%Function for reforming the tree, called multiple times within initialStep
%%until the subTree structure is stablized.
function madeChange=optimTree(i)

global cors;global pens;global superTree;global subTrees;global T;

DOS=superTree.directOffsprings{i};
madeChange=0;

if isempty(DOS)
    return;
end;

for j=1:length(DOS)
    optimTree(DOS(j));
end;

[lambda j]=max(cors(DOS)./pens(DOS));

if lambda>abs(cors(i))/pens(i)
    subTrees.directOffsprings{T.parents(DOS(j))}...
        =[subTrees.directOffsprings{T.parents(DOS(j))} DOS(j)];
    subTrees.parents(DOS(j))=T.parents(DOS(j));
    superTree.directOffsprings{i}=setdiff(superTree.directOffsprings{i},DOS(j));
    superTree.directOffsprings{i}=union(superTree.directOffsprings{i},superTree.directOffsprings{DOS(j)});
    superTree.directOffsprings{DOS(j)}=[];
    k=subTrees.parents(DOS(j));
    while k
        cors(k)=cors(k)+cors(DOS(j));
        pens(k)=pens(k)+pens(DOS(j));
        k=subTrees.parents(k);
    end;
    
    madeChange=1;
end;

if madeChange
    optimTree(i);
end;

if superTree.parents(i)==0
    subTrees=dos2tree(subTrees.directOffsprings);
    superTree=dos2tree(superTree.directOffsprings);
end;
%----------End of Initial Step------------------

%--------------------Update Direction----------------
function updateDirection()

global numErr;global XY;global T;global zGroup;global zList;global mGroup;
global mList;global head; global subTrees;global ETA;global d; global S;
global Delta;global cors;global pens;global b;global action;global Y;global X;


%calculate group directions
DD=inv( [ETA(:, mGroup) X(:,~head)]'*[ETA(:, mGroup) X(:,~head)] )...
                        *[pens(mGroup);zeros(sum(~head),1)];
Delta(mGroup)=DD(1:length(mGroup));
%calculate individual direction
for i=1:length(mGroup)
    d(subTrees.groups{mGroup(i)})=S(subTrees.groups{mGroup(i)})*Delta(mGroup(i));
end
d(~head)=DD(length(mGroup)+1:end);
d(zList)=0;


%--------------End of Update Direction----------------

%-------------------Combine zeroSubTrees------------------
function combineZeroSubTrees(i)
global bs;global superTree;global ETA;global Y;global pens;global X;global d;
global zGroup; global numErr;

DOS=superTree.directOffsprings{i};
parent=superTree.parents(i);

if parent==0|(~ismember(i,zGroup))
    bs(i)=inf;
else
    if abs( ((ETA(:,i)'*X*d)./pens(i)-ETA(:,parent)'*X*d/pens(parent) ) )<numErr
        bs(i)=inf;
    else
        bs(i)=(ETA(:,i)'*Y./pens(i)-ETA(:,parent)'*Y/pens(parent))...
            ./((ETA(:,i)'*X*d)./pens(i)-ETA(:,parent)'*X*d/pens(parent) );
    end;
end;


if isempty(DOS)
    return;
else
    for j=1:length(DOS)
        combineZeroSubTrees(DOS(j));
    end;
    return;
end;
%---------------------End of Combine zeroSubTrees
