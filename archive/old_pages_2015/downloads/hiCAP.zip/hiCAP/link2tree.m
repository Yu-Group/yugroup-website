function Tree=link2tree(n,links)

Tree.links=links;
Tree.directOffsprings=cell(1,n);
Tree.allOffsprings=cell(1,n);
Tree.parents=zeros(1,n);
Tree.groups=cell(1,n);
Tree.leafs=[];;
for i=1:length(links)
    j=links{i}(1);
    Tree.directOffsprings{j}=links{i}(2:end);
end;

for i=1:length(links)
    j=links{i}(1);
    Tree.allOffsprings{j}=dos2aos(j,Tree.directOffsprings);
end;

for j=1:n
    Tree.groups{j}=[j Tree.allOffsprings{j}];
end;

for j=1:n
    Tree.parents(Tree.directOffsprings{j})=j;
end;

for j=1:n
    if isempty(Tree.directOffsprings{j})
    Tree.leafs=union(Tree.leafs,j);
    end;
end;

Tree.roots=find(Tree.parents==0);