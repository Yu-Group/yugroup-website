function Tree=dos2tree(dos)

n=length(dos);
Tree.directOffsprings=dos;
Tree.allOffsprings=cell(1,n);
Tree.parents=zeros(1,n);
Tree.groups=cell(1,n);
Tree.leafs=[];;
Tree.parentRoot=zeros(1,n);
Tree.ancestors=cell(1,n);

for j=1:n
    Tree.allOffsprings{j}=dos2aos(j,Tree.directOffsprings);
end;

for j=1:n
    Tree.groups{j}=[j Tree.allOffsprings{j}];
end;

for j=1:n
    Tree.parents(Tree.directOffsprings{j})=j;
end;

for j=1:n
    if isempty(Tree.directOffsprings{j})
    Tree.leafs=union(Tree.leafs,j);
    end;
end;

Tree.roots=find(Tree.parents==0);

for j=1:length(Tree.roots)
    Tree.parentRoot(Tree.groups{Tree.roots(j)})=Tree.roots(j);
end;

for j=1:n
    for k=1:length(Tree.allOffsprings{j})
        Tree.ancestors{Tree.allOffsprings{j}(k)}=...
            union(Tree.ancestors{Tree.allOffsprings{j}(k)},j);
    end;
end;