function res = liglasso(y, x, grouping, options)

if(nargin<4)
  options = [];
end;

if(~isfield(options, 'matricial_input'))
  options.matricial_input = logical(0);
end;

if(~isfield(options, 'epsilon'))
  options.epsilon = 1e-6;
end;

matrix_input  = options.matricial_input;
my_eps        = options.epsilon;
k             = size(x,2);

% Convert grouping from cell to matrix if needed:
% =========================================================================
if(iscell(grouping))
  grouping = convert_grouping_cell_to_matrix(grouping, k);
end;

% Normalize data according to grouping:
% =========================================================================
normalized_data = group_normalization(y, x, grouping, matrix_input, Inf, options);
cte_idx         = normalized_data.constant_idx;
var_idx         = setdiff(1:k, find(cte_idx));

% Compute LIGLASSO path:
% =========================================================================
res                   = icap_engine(normalized_data.xty(var_idx), ...
                                    normalized_data.xtx(var_idx, var_idx), ...
                                    grouping, options);

% save normalization factors:
% =========================================================================
res.yscale            = normalized_data.yscale;
res.xscale            = normalized_data.xscale;
res.ymean             = normalized_data.ymeans;
res.xmean             = normalized_data.xmeans;

% save ``unnormalized'' coefficients:
% =========================================================================
res.nbeta             = res.beta;
rmfield(res, 'beta');
res.beta(:,cte_idx)   = zeros(size(res.nbeta, 1), sum(cte_idx)); 
res.beta(:,var_idx)   = res.yscale*res.nbeta(:,var_idx)*...
                        diag(1./res.xscale(var_idx));
res.intercept         = res.ymean-(res.xmean*res.beta')';

% save more penalty indices:
% =========================================================================
res.npenalty          = compute_penalty(res.nbeta, grouping);
res.penalty           = compute_penalty(res.beta, grouping);

% save Data:
% =========================================================================
if(~matrix_input)
  res.ny              = normalized_data.ny;
  res.nx              = normalized_data.nx;
  res.sample_size     = normalized_data.n_obs;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Auxiliary functions:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [pen, g_pen] = compute_penalty(betas, grouping)
g_norm=[];
for i = 1:size(grouping,1)
  for j = 1:size(betas,1)
    g_norm(j,i) = norm(betas(j, find(grouping(i,:))), Inf);
  end;
end;
g_pen = g_norm;
pen   = (sum(g_norm'))';
