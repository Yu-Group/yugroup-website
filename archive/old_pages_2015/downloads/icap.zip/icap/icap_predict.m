function [y_pred, y_residuals] = icap_predict(icap_obj, x, indices, options)
% -------------------------------------------------------------------------
% function y_pred = icap_predict(icap_obj, x, indices, options)
% -------------------------------------------------------------------------
% PURPOSE: This function returns the estimates for the model contained in
%          icap_object at the points listed in the matrix x
% -------------------------------------------------------------------------
% INPUTS:
% x:      is a n x p vector where n is the number of points to be predicted
%         and p is the dimension of the regressors
% a_icap_object: a icap object as the one returned by the 
%                 icap function
%                 it must contain an intercept and a beta field
% indices:
% options: a structure containing:
%          alignment: one of 'penalty', 'normalized_penalty', 'lambda'
% -------------------------------------------------------------------------
% OUTPUTS:
% y_pred:  the predicted values for the dependent variable along the 
%          regularization path
% -------------------------------------------------------------------------
% Author: Guilherme V. Rocha
%         Department of Statistics
%         University of California, Berkeley
%         gvrocha@stat.berkeley.edu, gvrocha@gmail.com
% 2006/09
% -------------------------------------------------------------------------
% See also: ICAP, ICAP_COEFFICIENTS
% -------------------------------------------------------------------------

if nargin <4;
  options = [];
end;
if nargin < 1;
  error('No parameters defined')
end;
compute_residuals = 0;
if((nargin <2)|(isempty(x)))
  x = repmat(icap_obj.xmean,  icap_obj.sample_size, 1) + ...
      repmat(icap_obj.xscale, icap_obj.sample_size, 1).*icap_obj.nx;
  y = icap_obj.ymean + icap_obj.yscale*icap_obj.ny;
  compute_residuals = 1;
end;


if(~isfield(options, 'alignment'))
  options.alignment = 'normalized_penalty';
end;

res = icap_coefficients(icap_obj, indices, options.alignment); 
n_path = size(res.beta, 1);
n_obs  = size(x, 1);
y_pred = repmat(res.intercept', n_obs, 1) + x*res.beta';
if(compute_residuals)
  y_residuals = y_pred-y;
else
  y_residuals = [];
end;
