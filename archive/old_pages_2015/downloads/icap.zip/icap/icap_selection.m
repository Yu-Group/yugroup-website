function res = icap_selection(icap_obj, method)
% -------------------------------------------------------------------------
% function res = icap_selection(icap_obj, method)
% -------------------------------------------------------------------------
% PURPOSE:
% This function uses Zou and Hastie's unbiased estimate of the 
% degrees of freedom of the icap to select the amount of regularization
% -------------------------------------------------------------------------
% INPUTS:
% icap_obj:  a structure as returned by the icap function
% method: one of the following strings (not case sensitive):
%         "aic": uses Akaike information criterion (AIC)
%         "bic": uses Schwartz's Bayesian information criterion (BIC)
%         "all": returns all selecctions above
% -------------------------------------------------------------------------
% OUTPUTS:
% A copy of the icap_obj structure with the following fields added 
% according to the choice of method:
% AIC: a structure containing:
%      path:      the path of the AIC criterion
%      minidx:    the index at which the AIC criterion is minimized
%      nbetas:    the normalized coefficients picked by AIC
%      betas:     the coefficients picked by AIC
%      intercept: the intercept picked by AIC
% BIC: a structure containing:
%      path:      the path of the BIC criterion
%      minidx:    the index at which the BIC criterion is minimized
%      nbetas:    the normalized coefficients picked by BIC
%      betas:     the coefficients picked by BIC
%      intercept: the intercept picked by BIC
% -------------------------------------------------------------------------
% Author: Peng Zhao and Guilherme V. Rocha
%         Department of Statistics
%         University of California, Berkeley
%         gvrocha@stat.berkeley.edu, gvrocha@gmail.com
% 2006/09
% -------------------------------------------------------------------------
%
% SEE ALSO ICAP

res = icap_obj;

y   = res.ymean+res.yscale*res.ny;
x   = repmat(res.xmean, res.n_obs,1)+res.nx*diag(res.xscale);

r     = y*ones(1,size(res.betas,1))-ones(length(y),1)*res.intercepts'-x*res.betas';
s     = sqrt(sum(r(:,end).^2)/(length(y)-sum(res.betas(end,:)~=0))); 
sigma = s;
R2    = sum(r.^2,1)/s^2;
    
if strcmpi(method,'AIC')|strcmpi(method,'all')
  res.AIC.path           = res.R2+2*res.df;
  [dummy,res.AIC_minidx] = min(res.AIC.path);                       
  res.AIC.beta             = res.beta(res.AIC_minidx,:);                  
  res.AIC.intercept      = res.intercept(res.AIC_minidx,:);             
end;

if strcmpi(method,'BIC')|strcmpi(method,'all')
  res.BIC.path           = res.R2+log(res.n_obs)*res.df;
  [dummy,res.BIC_minidx] = min(res.BIC.path);                          
  res.BIC.beta           = res.beta(res.BIC_minidx,:);                     
  res.BIC.intercept      = res.intercept(res.BIC_minidx,:);               
end;
