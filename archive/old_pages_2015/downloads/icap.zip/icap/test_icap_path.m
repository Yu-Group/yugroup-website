function check_res = test_icap_path(icap_object, options)
% ================================================================================================
% function check_res = test_icap_path(icap_object, options)
% ================================================================================================
% Checks the results in icap_object for errors.
% The following five conditions are checked:
% Conditions:
% 1) X_{j}'R \neq 0                               => beta_{j}= sign(X_{j}'R)*argmax_{k \in group of j}beta_{k}
% 2) |beta_{j}|<argmax_{k \in group of j}beta_{k} => X_{j}'R = 0
% 3) beta_{G_{j}} \neq 0                          => |X_{G_{j}}'R|_{1} = max_{k}|X_{G_{k}}'R|_{1}
% 4) X_{A^{c}}'R < max_{k}|X_{G_{k}}'R|_{1}       => beta_{G_{j}} = 0 
% 5) max_{k}|X_{G_{k}}'R|_{1} = \lambda
% 6) icap_object.xtrs = xty - xtx * beta
% 7) icap_object.b = max_by_group(abs(nbeta))
% ================================================================================================
% OUTPUT:
% check_res is a structure containing:
%          .table_condition: a n_betas x 5 cell containing indicator of errors for each variable/group for each of the five conditions above
%          .errors:          a n_betas x 5 cell containing indicator variables for each point in path for each condition
%          .error_positions: a vector containing the index of steps with potential problems
%          .ok             : a boolean variable indicating whether any potential problem was found 
% ================================================================================================
% See also ICAP
% ================================================================================================
if(nargin<2)
  options = [];
end;

n_groups = size(icap_object.G,1);
p        = size(icap_object.G,2);
n_steps  = size(icap_object.nbeta,1);

if(isfield(options, 'epsilon'))
  my_eps = options.epsilon;
elseif(isfield(icap_object.options, 'epsilon'))
  my_eps = icap_object.options.epsilon;
else
  my_eps = 1e-6;
end;
G = icap_object.G;

max_coefficients     = NaN * zeros(n_steps, n_groups);
rep_max_coefficients = NaN * zeros(n_steps, p);
for i = 1:n_groups
  group_size(i)                        = length(find(G(i,:)));
  max_coefficients(:,i)                = max(abs(icap_object.nbeta(:,find(G(i,:))))', [], 1)';
  rep_max_coefficients(:,find(G(i,:))) = repmat(max_coefficients(:,i), 1, group_size(i));
end;
group_correlations         = icap_object.gxtrs;
max_group_correlations     = max(abs(icap_object.gxtrs'))';
rep_max_group_correlations = repmat(max_group_correlations, 1,n_groups);

% Checking conditions:
check_res.error_condition_table{1}   = ((abs(icap_object.nbeta)-rep_max_coefficients)>=my_eps).*(sign_with_tol(icap_object.xtrs, my_eps)==0);
check_res.error_condition_table{2}   = ((abs(icap_object.nbeta)-rep_max_coefficients)<=-my_eps).*(sign_with_tol(icap_object.xtrs, my_eps)~=0);
check_res.error_condition_table{3}   = (abs(icap_object.b)>my_eps).*(abs(icap_object.gxtrs)<=rep_max_group_correlations-my_eps);
check_res.error_condition_table{4}   = (abs(icap_object.b)<=my_eps).*(abs(icap_object.gxtrs)>=rep_max_group_correlations+my_eps);
check_res.warning_condition_table{1} = abs(max_group_correlations - icap_object.lambda)>=my_eps;
check_res.warning_condition_table{2} = abs(repmat(icap_object.xty', n_steps, 1) - icap_object.nbeta*icap_object.xtx  - icap_object.xtrs)>=my_eps;
check_res.warning_condition_table{3} = icap_object.b-max_coefficients<=-my_eps;
check_res.warning_condition_table{4} = any(icap_object.halting_flag);

% Summarizing conditions:
for i = 1:length(check_res.error_condition_table)
  check_res.errors(:,i) = any(check_res.error_condition_table{i}', 1)';
end;

for i = 1:length(check_res.error_condition_table)
  check_res.warnings(:,i) = any(check_res.warning_condition_table{i}', 1)';
end;

check_res.error_positions   = find(any(check_res.errors')');
check_res.found_errors      = any(check_res.errors);

check_res.warning_positions = find(any(check_res.warnings')');
check_res.found_warnings    = any(check_res.warnings);

function signs = sign_with_tol(x, my_eps)

signs = -1.*(x<-my_eps) + 1.*(x<-my_eps);
