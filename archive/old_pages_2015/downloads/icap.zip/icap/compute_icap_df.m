function [dfs, dfs_per_group] = compute_icap_df(betas, G, options)

if(nargin<3)
  options = [];
end;

if(~isfield(options, 'epsilon'))
  options.epsilon = 1e-8;
end;

my_eps = options.epsilon;

for k = 1:size(G,1);
	idxs = find(G(k,:)~=0);
	if(size(idxs,2)==1)       % ie, there is only one variable in this group
		max_betas                                      = abs(betas(:,idxs)');
		num_variables_in_group(k,:)                    = zeros(1, size(max_betas, 2));
		num_variables_in_group(k, max_betas >= my_eps) = 1;                            % Check whether variable is  greater than zero
		loose_coefficients                             = zeros(size(max_betas));       %  no loose variables: the single variable is at the boundary
  else                      % the usual case...
		max_betas                                      = max(abs(betas(:,idxs)'));
		num_variables_in_group(k,:)                    = zeros(1, size(max_betas, 2));
		num_variables_in_group(k, max_betas >= my_eps) = 1;
		loose_coefficients                             = sum(abs(betas(:,idxs)') <= kron(max_betas, ones(max(size(idxs)), 1))-my_eps);
	end;
	num_variables_in_group(k,:) = num_variables_in_group(k,:) + loose_coefficients;
end;
dfs_per_group	= num_variables_in_group';
dfs						= sum(num_variables_in_group)';
