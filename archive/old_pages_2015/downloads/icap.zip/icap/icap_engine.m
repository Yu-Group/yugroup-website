function result = icap_engine(xty, xtx, G, options)
% -------------------------------------------------------------------------
% function result = icap_engine(xty, xtx, G, options)
% -------------------------------------------------------------------------
% PURPOSE:
% This is an implementation of the LARS algorithm for getting the icap 
% path in MATLAB.
%
% -------------------------------------------------------------------------
% INPUTS:
% y:     a n x 1 vector containing the values of the dependent variable
% x:     a n x p matrix containing the values of the predictors
% options: a structure containing options for the liglasso
%          - max_steps (default = 'Inf'): number of steps until stopping
%          - trace (default = 0): boolean flagging whether progress should be output to screen (1) or not (0) 
% -------------------------------------------------------------------------
% OUTPUTS:
% A structure containing the following fields:
% .nbetas:      the values of the coefficients for x and y normalized 
% .betas:       the values of the coefficients in the original scales
% .intercepts:  the values of the intercepts in the original scales
% .xscale:      the constant by which each x was normalized
% .yscale:      the normalizing constant for y
% .ymean:       the mean of the y vector
% .xmean:       the means of the columns of x
% .npenalties:  the L1 norm of the coefficients along the path for the 
%               normalized Xs;
% .penalties:   the L1 norm of the coefficients along the path for the
%               unnormalized Xs
% .lambdas:     values of the regularization parameter along the path
%               equals ||nx'*(ny-nx'*beta(\lambda)||_{\infty}
% .nx:          a nxp design matrix with the normalized predictors
% .ny:          a nx1 vector containing the values of the response variable
% .sample_size: number of observations used to trace path
% .dfs:         extension of Zou and Hastie (2004)'s unbiased estimate of the degrees of freedom along the path
% -------------------------------------------------------------------------
% Author: Peng Zhao and Guilherme V. Rocha
%         Department of Statistics
%         University of California, Berkeley
%         gvrocha@stat.berkeley.edu, gvrocha@gmail.com
% 2006/09
% -------------------------------------------------------------------------
% Revision on August/2007
% - Need to implement Cholesky update/downdate to avoid inverting H below at each step
% - If H becomes singular, algorithm halts (how should updates resulting in LD cases be dealt with?)
% -------------------------------------------------------------------------
% See also icap_CV, icap_COEFFICIENTS

% 0 Checking inputs and filling in defaults:
% =========================================================================
global n_g my_eps;

if nargin<4
  options=[];
end;

if(~isfield(options, 'max_steps'))
  options.max_steps = Inf;
end;

if(~isfield(options, 'trace'))
  options.trace = logical(0);
end;

if(~isfield(options, 'debug'))
  options.debug = logical(0);
end;

if(~isfield(options, 'epsilon'))
  options.epsilon = 1e-8;
end;

if(options.epsilon<eps*1e3)
  warning('Required precision is within a factor of 1e3 of machine precision. Using epsilon=1e3*machine_precision instead.');
  options.epsilon = 1e3*eps;
end;

if(~isfield(options, 'max_dfs'))
  options.max_dfs = Inf;
end;

if(~isfield(options, 'min_lambda'))
  options.min_lambda = options.epsilon;
end;

if(~isfield(options, 'screen_output'))
  options.screen_output = logical(0);
end;

% Setting optional parameters:
% =========================================================================
max_dfs       = options.max_dfs;
max_steps     = options.max_steps;
trace         = options.trace;
screen_output = options.screen_output;
debug         = options.debug;
min_lambda    = options.min_lambda;
my_eps        = options.epsilon;

if nargin<2
  error('No predictors provided.');
  return;
end;

% =========================================================================
k           = size(xtx, 2);                                                % this is the number of regressors
all_indices = (1:k)';
n_g         = size(G,1);

% =========================================================================
xscale             = sqrt(diag(xtx));
constant_idxs      = xscale <= my_eps;
ignore_list        = constant_idxs;
variables_list     = sort(setdiff(all_indices, find(constant_idxs)));      % list of "actual" variables (they DO vary)
actions            = -ignore_list;                                         % Registers the exclusion of the ignored variables in the action vector

if(screen_output)                                                          % If trace was requested, list ignored variables to screen
  for i = 1:size(ignore_list,2)
    disp(['Adding ' num2str(ignore_list(i),3) ' to ignore list - constant']);
  end;
end;

possible_events = {'add_group', ...
                   'drop_group', ...
                   'release_coefficient', ...
                   'constrain_coefficient', ...
                   'change_of_sign', ...          % when a coefficient should be released in a inactive group: nothing happens but need to keep track of correlations signs
                   'end_of_path'};

% 0.4 Computes "correlations" - that is all we need:
% =========================================================================
xtr   = xty;
sign_matrix = get_sign_matrix(xtr, G);
g_xtr = sign_matrix'*xtr;

% 1.a Initial point of the path:
% =========================================================================
b              = zeros(n_g, 1);
beta           = zeros(k, 1);                                              % Path starts at zero
lambda         = norm(g_xtr,Inf);
curr_df        = 0;
nvg            = sum(abs(sign_matrix))';                                   % number of variables at the border of a group

% 1.b Initial point of the path:
% =========================================================================
betas          = beta';                                                    % Path starts at zero
bs             = b';
dfs            = curr_df;
lambdas        = lambda;
if(trace)
  xtrs           = [xtr'];
  g_xtrs         = [g_xtr'];
end;
if(debug)
  conds = [NaN];
  As    = logical(zeros(1,n_g));
  Us    = logical(zeros(1,k));
end;

% 1.c Initializing control variables:
% =========================================================================
model_size     = 0;                                                        % No variable has been selected in the beginning
Ag             = [];                                                       % No active groups in the beginning
U              = [];                                                       % these are the variables with zero correlation
Ag_c           = setdiff(1:n_g, Ag);                                       
Uc             = setdiff(1:k,   U);                                        % updates the complement of unrestricted variables
n_Ag           = length(Ag);                                               % updates the number of active group s
n_U            = length(U);                                                % updates the number of unrestricted variables 

n_steps         = 0;
dlambda         = -Inf;
group_norms     = zeros(n_g, 1);
next_break      = 1;
db              = ones(n_g, 1);                                             % just to start up,no group is active right now so this is not used
b_signs         = sign(b);                                                  % To force b to be positive, I must keep track of whether group correlation value increases or decreases (b only cares about size)
halting_history = 0;
singular_flag   = 0;

% 2.     normal equations are not satisfied (lambda~=0)
%    AND n_steps is smaller than the maximal
%    AND lambda is still decreasing noticeably
% =========================================================================
while((lambdas(end)>min_lambda)&(n_steps<max_steps)&(curr_df<max_dfs)&(dlambda<-my_eps))
  
  halted_flag             = 0;
  restricted_variables    = [];                                            % Finds out which unrestricted variables hit the boundary
  for i = 1:n_Ag                                                           % Only variables in active groups are allowed to wander around: no need to check over inactive groups
    Ui                    = intersect(U, find(G(Ag(i),:)));
    temp_U_i              = Ui(find(abs(beta(Ui))>b(Ag(i))-my_eps));
    restricted_variables  = [restricted_variables temp_U_i];
    sign_matrix(temp_U_i,Ag(i)) = sign(beta(temp_U_i));
  end;

  dropped_groups         = find(abs(b(Ag))<my_eps*mean(abs(db)));          % Finds out which active groups should be dropped
  for i = 1:length(dropped_groups)
    Ui                   = intersect(U, find(G(Ag(dropped_groups(i)),:)));
    restricted_variables = [restricted_variables Ui];
  end;

  added_groups    = Ag_c(find(abs(g_xtr(Ag_c))>lambda-my_eps));            % Finds out which inactive groups should be activated
  freed_variables = zeros(0,2);                                            % Finds out which constrained variables should be let wander freely
  for i = 1:length(Ag)                                                     % only variables in active group are allowed to wander around
    Uc_i                   = intersect(Uc, find(G(Ag(i),:)));
    temp_Uc_i              = Uc_i(find(abs(xtr(Uc_i))<my_eps));
    freed_variables        = [freed_variables; temp_Uc_i' Ag(i)*ones(length(temp_Uc_i),1)];
  end;
  
  % If a freed variable is in a dropped group, prevent it from going wild:
  freed_in_dropped = ismember(freed_variables(:,2), dropped_groups);
  freed_variables  = freed_variables(~freed_in_dropped, :);
  
  b_signs(added_groups)       = 1;                                                                % temporarily set the direction of the new group to one: if this causes the new b to go negative, we will flip it later 
  b_signs(Ag(dropped_groups)) = 0;                                                                % resets b_signs of dropped groups: not necessary but should make results more clear

  Ag      = setdiff(union(Ag, added_groups), Ag(dropped_groups));                             % updates active group
  U       = setdiff(union(U,  freed_variables(:,1)), restricted_variables);                   % updates unrestricted variables
  Ag_c    = setdiff(1:n_g, Ag);                                                               % updates the complement of active groups
  Uc      = setdiff(1:k,   U);                                                                % updates the complement of unrestricted variables
  n_Ag    = length(Ag);                                                                       % updates the number of active groups
  n_U     = length(U);                                                                        % updates the number of unrestricted variables

  new_group_indices           = find(ismember(Ag, added_groups));
  
  check_freed = 1;
  while(check_freed)
    H  = [sign_matrix(:,Ag)'*xtx*sign_matrix(:,Ag)  sign_matrix(:,Ag)'*xtx(:,U);             % H is the Hessian of the active groups and unrestricted variables;
          xtx(U,:)*sign_matrix(:,Ag)          xtx(U, U)];                                
    temp_db             = H\[b_signs(Ag);zeros(length(U),1)];              % temp_db is a (number active groups+number of unrestricted variables) vector:
                                                                           % the first     n_Ag terms are the variation in the active group maximal coefficients: we adjust by b_signs to keep b positive
                                                                           % the following n_U  terms are the variation in the "free coefficients"
    db                     = zeros(n_g,1);                                 % db is change in the maximal group coefficiets 
%    sign_adj               = ones(n_g, 1);
%    sign_adj(added_groups) = sign(temp_db(new_group_indices));
%    b_signs(added_groups)  = sign(temp_db(new_group_indices));
    db(Ag)                 = temp_db(1:n_Ag);                % only active groups have nonzero db entries
    dbeta                  = sign_matrix*db;                               % dbeta is the change in all coefficients
    dbeta(U)               = temp_db(n_Ag+1:end);                          % temp_db(n_Ag+1:end) contains variation for variables in U
    
    % =====================================================================
    % The code below checks whether a freed variable will try to move faster than its group
    % This may never happen, but at the moment no theory backing this up;
    % =====================================================================
    
    freed_variables_speed       = sign(beta(freed_variables(:,1))).*dbeta(freed_variables(:,1));
    freed_variables_group_speed = db(freed_variables(:,2));
    
    halted_indices              = freed_variables_speed>freed_variables_group_speed;
    halted_variables            = freed_variables(find(halted_indices), :);
    if(isempty(halted_variables))
      check_freed = 0;
    else
      halted_flag             = 1;
      U  = setdiff(U, halted_variables(:, 1));
      Uc = setdiff(1:k,   U);
      for m = 1:size(halted_variables, 1)
        sign_matrix(halted_variables(m,1),halted_variables(m,2)) = sign(beta(halted_variables(m,1)));
      end;      
      freed_variables = freed_variables(find(~halted_indices),:);
    end;
    
    % =====================================================================
    % END OF THE CHECK OF FREED VARIABLE SPEED
    % =====================================================================
  end;
  
  % Not ideal treatment but at least avoid unstable results for the time being
  if(rcond(H)<my_eps)
    if(debug)
      conds         = [conds;cond(H)];
    end;
    singular_flag = 1;
    warning('icap algorithm exiting: matrix H has become singular');
    break;
  end;
  
  if(debug)
    conds      = [conds;cond(H)];
    temp       = zeros(1, n_g);
    temp(:,Ag) = 1;
    As         = [As; temp];
    temp       = zeros(1, k);
    temp(:,U)  = 1;
    Us         = [Us; temp];
  end;
    
  % 2c.i Compute ste size where a group should be activated:
  % =====================================================================
  if(~isempty(Ag_c))
    n1		   = lambda - g_xtr(Ag_c);
    n2		   = lambda + g_xtr(Ag_c);
    d1		   = 1 - sign_matrix(:,Ag_c)'*[xtx*sign_matrix(:,Ag) xtx(:,U)]*[db(Ag);dbeta(U)];
    d2		   = 1 + sign_matrix(:,Ag_c)'*[xtx*sign_matrix(:,Ag) xtx(:,U)]*[db(Ag);dbeta(U)];
    v1		   = n1./d1;
    v2		   = n2./d2;
    if(all([v1 v2]<=my_eps))
      candidate_gamma(1) = Inf;
    else
      candidate_gamma(1) = min([v1(v1>=my_eps);v2(v2>=my_eps)]);
    end;
  else
    candidate_gamma(1) = Inf;
  end;

  % 2c.ii Compute step size where a group will be deactivated:
  % =====================================================================  
  zc_gammas = -b(Ag)./db(Ag);
  if(all(zc_gammas<=my_eps))
    candidate_gamma(2) = Inf;
  else
    candidate_gamma(2)  = min(zc_gammas(zc_gammas>my_eps));
  end;
  % It is a good idea to somehow replicate the order of magnitude calculations in 2c.iv below here.
  % This condition is on the coefficients and gamma is determined in terms of correlations
  
  % 2c.iii Compute step size where a currently restricted variable will be
  %        changed to the unrestricted set 
  % =====================================================================
  zcorr_gammas = [];
  for i = 1:n_Ag
    Uc_i = intersect(Uc, find(G(Ag(i),:)));
    % Change: compute the gamma that makes the correlation go beyond zero by a 0.5*epsilon to make signs more stable
    % zcorr_gammas = [zcorr_gammas;xtr(Uc_i)./(xtx(Uc_i,:)*dbeta)];
    zcorr_gammas = [zcorr_gammas;(xtr(Uc_i)+sign_matrix(Uc_i, Ag(i))*my_eps/2)./(xtx(Uc_i,:)*dbeta)];
  end;
  if(all(zcorr_gammas<=my_eps))
    candidate_gamma(3) = Inf;
  else
    candidate_gamma(3) = min(zcorr_gammas(zcorr_gammas>my_eps));
  end;
  
  % 2c.iv compute step size where a unrestricted parameter will hit the group boundary
  % =====================================================================
  bc_gammas = [];
  coefficient_margins = [];                                                % This is the margin between an unconstrained coefficient and its corresponding boundary
  coefficient_speeds  = [];                                                % This is the speed at which an unconstrained coefficient is approaching its boundary
  for i = 1:n_g
    Ui                  = intersect(U, find(G(i,:)));
    if(~isempty(Ui))
      coefficient_indices = n_Ag + find(ismember(U,Ui));                   % finding the update for Ui coefficient within db;
      bc_gammas = [  bc_gammas;
                    (b(i)-beta(Ui))./(temp_db(coefficient_indices)-db(i));
                   -(b(i)+beta(Ui))./(temp_db(coefficient_indices)+db(i))];
      coefficient_margins = [ coefficient_margins; 
                              (b(i)-beta(Ui));
                             -(b(i)+beta(Ui))];
      coefficient_speeds  = [ coefficient_speeds;
                              (temp_db(coefficient_indices)-db(i));
                              (temp_db(coefficient_indices)+db(i)) ];
    end;
  end;
  
  % This is a (possibly lousy) way to adjust precision in terms of steps in lambda and their effects in terms of coefficient sizes 
  % The minimum gamma step size must be small enough to perceive a change of the same order as my_eps in the coefficient space
  margin_order = log10(my_eps);                                            % This is the smallest order of magnitude we want to distinguish
  speed_order  = log10(max(abs(coefficient_speeds)));                      % A step of size one in gamma will have this order of magnitude at worse
  bc_gamma_eps = 10^(margin_order-speed_order);
  if(all(bc_gammas<=bc_gamma_eps))
    candidate_gamma(4) = Inf;
  else
    candidate_gamma(4)  = min(bc_gammas(bc_gammas>bc_gamma_eps));
  end;

  % 2c.v compute step size that will cause the correlation of a varible in an inactive group to flip sign
  % =====================================================================
  zcorr_gammas = [];
  for i = 1:(n_g-n_Ag)
    Uc_i = intersect(Uc, find(G(Ag_c(i),:)));
    zcorr_gammas = [zcorr_gammas;(xtr(Uc_i)+sign(xtr(Uc_i))*1.1*my_eps)./(xtx(Uc_i,:)*dbeta)];   % addition of 1.1*sign(xtr(Uc_i))*my_eps makes sure that we can detect right sign later...
  end;
  if(all(zcorr_gammas<=my_eps))
    candidate_gamma(5) = Inf;
    alternative_zcross_gamma = Inf;
  else
    zcorr_gammas = sort(zcorr_gammas(zcorr_gammas>my_eps));
    candidate_gamma(5) = zcorr_gammas(1);
  end;

  % 2d. Sets step size:
  % =====================================================================
  [gamma, next_break] = min([candidate_gamma lambda]);

  % 2e. Compute lambda where next exciting event happens:
  % =====================================================================
  lambda   = lambda - gamma;
  beta     = beta   + gamma*dbeta;
  b        = b      + gamma*db;
  
  curr_df  = compute_icap_df(beta', G, options);
  xtr      = xtr - gamma*xtx*dbeta;                                        % xtr is a vector with the correlations between current residuals and the explanatory variables
  sign_matrix    = get_sign_matrix(xtr, G);
  g_xtr    = sign_matrix'*xtr;
  nvg      = sum(abs(sign_matrix))';
  
  if(trace)
    xtrs            = [xtrs;xtr'];
    g_xtrs          = [g_xtrs;g_xtr'];
    halting_history = [halting_history;halted_flag];;
  end;
  
  dfs      = [dfs; curr_df];
  betas    = [betas;beta'];
  bs       = [bs;b'];
  lambdas  = [lambdas; lambda];
  
  n_steps  = n_steps+1;

  % Check if we are still moving foward:
  if(next_break == 4)                                                      % In this case, the lambda step may be small due to the coefficients being very tiny, so we relax the condition a bit
    dlambda = -gamma * 10^(speed_order);
  else
    dlambda = -gamma;
  end;

end;

% 3. Storing the results in output structure
%==========================================================================
%not_ignore_list              = setdiff(all_indices, ignore_list);
variable_list                = setdiff(all_indices, find(constant_idxs));

% Path:
result.beta                  = NaN*ones(n_steps+1, k); % 0 is not a step
result.beta(:,constant_idxs) = zeros(size(betas, 1), sum(constant_idxs)); 
result.beta(:,variable_list) = betas;
result.b                     = bs;
if(trace)
  result.xtrs                = xtrs;
  result.gxtrs               = g_xtrs;
end;

if(debug)
  result.A                = As;
  result.U                = Us;
  result.halting_flag     = halting_history;
end;

% Indices:
result.lambda                = lambdas;
result.df                    = dfs;

% Data:
result.xty    = xty;
result.xtx    = xtx;

% Settings:
result.options               = options;
result.G                     = G;

% Warning flags:
result.singularity           = singular_flag;

%==========================================================================
% End of icap_engine function
%==========================================================================
  
%==========================================================================
function S = get_sign_matrix(xtr, G)
  global n_g;
  S   = G'.*repmat(tol_sign(xtr), 1, n_g);

%==========================================================================
function s = tol_sign(x)
  global my_eps;
  s = -(x<-my_eps)+(x>my_eps);
  
%==========================================================================
