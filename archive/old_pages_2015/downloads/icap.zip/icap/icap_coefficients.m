function res = icap_coefficients(icap_object, indices, alignment)
% -------------------------------------------------------------------------
% function res = icap_coefficients(icap_object, indices, alignment)
% -------------------------------------------------------------------------
% PURPOSE: This function returns the icap coefficients for which the 
%          chosen index equals those listed in indices.
%          The alignment index can be chosen to be:
%          lambdas, normalized L1 norms and L1 norms;
% -------------------------------------------------------------------------
% INPUTS:
% icap_object: a structure as the one returned by the icap routine:
% indices:      index of the points at which interpolation is wanted
% alignment:    one string of ('normalized_l1', 'l1', 'lambdas')
%               indicating which index to use for alignment
% -------------------------------------------------------------------------
% OUTPUTS:
% res:          a structure containing  the coefficients and the measures
%               of regularization at the interpolated points
%               .intercept:
%               .nbeta:
%               .beta:
%               .lambda:
% -------------------------------------------------------------------------
% Author: Guilherme V. Rocha
%         Department of Statistics
%         University of California, Berkeley
%         gvrocha@stat.berkeley.edu, gvrocha@gmail.com
% 2006/09
% -------------------------------------------------------------------------
% See also: ICAP

% 0. Checking input parameters:
%==========================================================================
if nargin < 3
  alignment = 'normalized_penalty';
end;

% 1. Interpolates according to the chosen L1 norm (normalized x non normalized)
%==========================================================================
switch(lower(alignment))
  case{'normalized_penalty'}
    sizes = icap_object.npenalty;
  case{'penalty'}
    sizes = icap_object.penalty;
  case{'lambda'}
    sizes = icap_object.lambda;
  otherwise
    error('Unrecognized alignment string');
end;

% Takes care of the case when there are entries with repeated penalty values:
[unique_sizes, I, J]   = unique(sizes);

% If one of the points to be calculated is beyond the end of the path, use
% the end of path coeffcients for it:
indices       = min(indices, max(sizes));
res.intercept = interp1(unique_sizes, icap_object.intercept(I), indices');
res.beta      = interp1(unique_sizes, icap_object.beta(I,:), indices');
res.nbeta     = interp1(unique_sizes, icap_object.nbeta(I,:), indices');
res.lambda    = interp1(unique_sizes, icap_object.lambda(I,:), indices');
res.indices   = indices';
