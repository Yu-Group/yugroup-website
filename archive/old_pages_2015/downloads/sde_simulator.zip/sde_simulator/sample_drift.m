function mu = sample_drift(x, A)
% =========================================================================
% function mu = sample_drift(x, A)
% =========================================================================
% PURPOSE:
% a function implementing the drift of a geometric brownian motion
% =========================================================================
% INPUTS:
% x:  the p-dimensional state vector (assumed to be a column vector)
% A:  a pxp-matrix determining the drift of the geometric brownian motion
% =========================================================================
% OUTPUTS:
% mu: the p-dimensional drift at x: A*x
% =========================================================================
% Comments:
% - Created in 2007/06/04
% =========================================================================
% Guilherme V. Rocha: gvrocha [AT] gmail [dot] com
% =========================================================================

mu = A*x;
