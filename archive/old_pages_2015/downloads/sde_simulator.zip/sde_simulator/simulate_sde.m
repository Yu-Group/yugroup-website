function [X, W] = simulate_sde(X0, dt, T, mu, sigma, options)
% =========================================================================
% function [X, W] = simulate_sde(x0, dt, T, mu, sigma, options)
% =========================================================================
% PURPOSE:
% Simulates:
% X_{t+dt} = \mu(X_{t})X_{t} + CHOL(\sigma(X_{t}))W_{t}
% =========================================================================
% INPUTS:
% x0:      initial state (p-dimensional column vector)
% dt:      time step size
% mu:      a function that receives a -p-dimensional column (state) vector X as its parameter 
%          (must return a pxp matrix)
% sigma:   a function that receives a -p-dimensional column (state) vector X as its parameter
%          and returns a SQUARE ROOT/CHOLESKY DECOMPOSITION of the instantenous covariance matrix
% options: a structure containing optional arguments:
%          .q: dimension of the random factor W_{t} [default: q=p]
% =========================================================================
% OUTPUTS:
% X:       a nxp matrix where the k-th row contains the p-dimensional 
%          state vector X at time t_{0}+k*dt
% W:       is the sequence of gaussian white noise variables used to
%          generate X
% =========================================================================
% Comments:
% - Created in 2007/06/04
% - Uses a Runge-Kutta scheme in
%   "Some Issues in Discrete Approximation Solution to SDEs"
%   Komori, Saito, Mitsui, 1994
%   Computers MAth. Applic.
% =========================================================================
% Guilherme V. Rocha: gvrocha [AT] gmail [dot] com
% =========================================================================

if(nargin<6)
  options = [];
end;

if(~isfield(options, 'q'))
  options.q = size(X0, 2);
end;

if(~isfield(options, 'state'))
  options.state = [];
end;

p      = size(X0, 1);
q      = options.q;
state  = options.state;
N      = ceil(T/dt);

if(~isempty(state))
  randn('state', state);
end;

W      = randn(N+1, q);
X      = NaN*ones(N+1, p);

X(1,:) = X0';
for j  = 2:N+1
  mu_t     = mu(X(j-1,:)');
  sigma_t  = sigma(X(j-1,:)');
  hat_xn   = X(j-1,:)' + mu_t*dt + sigma_t*sqrt(dt)*W(j-1,:)';
  xj_plus  = X(j-1,:)' + mu_t*dt + sigma_t*sqrt(dt)*ones(q,1);
  xj_minus = X(j-1,:)' + mu_t*dt - sigma_t*sqrt(dt)*ones(q,1);
  
  dX     = 0.50 * (mu(hat_xn) + mu_t) * dt... 
         + 0.25 * (sigma(xj_plus) + sigma(xj_minus) + 2*sigma_t)*sqrt(dt)*W(j-1,:)' ...
         + 0.25 * (sigma(xj_plus) - sigma(xj_minus))*sqrt(dt)*((W(j-1,:)').^2-ones(q,1));
  X(j,:) = X(j-1,:) + dX';
end;
