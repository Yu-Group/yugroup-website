clear variables;
n_rep = 500;
A     = [-0.9 0;0 -0.5];
%B     = [1 0;0.125 0.125;0 0.5];
B     = [1 0;0.0 0.0;0 0.5];

f  = @(x)sample_drift(x, A);
G  = @(x)sample_volatility(x, B);

X0 = [0 0]';

T  = 30;
dt = 0.01;

options.q = 2;

X{1} = NaN*ones(ceil(T/dt)+1, n_rep);
X{2} = NaN*ones(ceil(T/dt)+1, n_rep);

fprintf('\n');
for i = 1:n_rep;
  Z = simulate_sde(X0, dt, T, f, G, options);
  X{1}(:,i) = Z(:,1);
  X{2}(:,i) = Z(:,2);
  fprintf('.');
  if(~mod(i, 10));fprintf(num2str(i/10,'%d'));end;
end;
fprintf('\n');

