function sigma = sample_volatility(x, B)
% =========================================================================
% function sigma = sample_volatility(x, B)
% =========================================================================
% PURPOSE:
% a function implementing the instantaneous volatility of a geometric brownian motion
% =========================================================================
% INPUTS:
% x:  the p-dimensional state vector (assumed to be a column vector)
% B:  a pxp-matrix determining the drift of the geometric brownian motion
% =========================================================================
% OUTPUTS:
% sigma: the cholesky decomposition of the instantaneuos covariance matrix
% =========================================================================
% Comments:
% - Created in 2007/06/04
% =========================================================================
% Guilherme V. Rocha: gvrocha [AT] gmail [dot] com
% =========================================================================

temp  = B*sqrt(abs(x));
sigma = [temp(1) temp(2);0 temp(3)];
